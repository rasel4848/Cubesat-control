import React from 'react';
import { useSatellite } from '../../context/SatelliteContext';
import { Thermometer } from 'lucide-react';
import { getStatusColor, formatTemperature } from '../../utils/mockData';

const TemperaturePanel: React.FC = () => {
  const { satelliteState } = useSatellite();
  const { temperature } = satelliteState.currentSensorData;

  const temperatureItems = [
    { 
      label: 'External', 
      value: temperature.external,
      icon: <Thermometer size={18} />,
      colorClass: getStatusColor(temperature.external, { warning: -25, critical: -40 }, false) 
    },
    { 
      label: 'Internal', 
      value: temperature.internal,
      icon: <Thermometer size={18} />,
      colorClass: getStatusColor(temperature.internal, { warning: 30, critical: 40 }, true)
    },
    { 
      label: 'CPU', 
      value: temperature.components.cpu,
      icon: <Thermometer size={18} />,
      colorClass: getStatusColor(temperature.components.cpu, { warning: 60, critical: 80 }, true)
    },
    { 
      label: 'Battery', 
      value: temperature.components.battery,
      icon: <Thermometer size={18} />,
      colorClass: getStatusColor(temperature.components.battery, { warning: 40, critical: 50 }, true) 
    },
    { 
      label: 'Camera', 
      value: temperature.components.camera,
      icon: <Thermometer size={18} />,
      colorClass: getStatusColor(temperature.components.camera, { warning: 35, critical: 45 }, true) 
    }
  ];

  return (
    <div className="bg-slate-800 rounded-lg shadow-lg p-4 text-white">
      <h2 className="text-xl font-bold mb-4">Temperature Readings</h2>
      
      <div className="space-y-3">
        {temperatureItems.map((item, index) => (
          <div key={index} className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className={item.colorClass}>{item.icon}</span>
              <span className="text-gray-300">{item.label}</span>
            </div>
            <div className={`font-medium ${item.colorClass}`}>
              {formatTemperature(item.value)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TemperaturePanel;