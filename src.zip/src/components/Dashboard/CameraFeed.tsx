import React, { useState } from 'react';
import { useSatellite } from '../../context/SatelliteContext';
import { Camera, Download, RefreshCw } from 'lucide-react';

const CameraFeed: React.FC = () => {
  const { satelliteState, captureImage } = useSatellite();
  const [isCapturing, setIsCapturing] = useState(false);
  const [showGallery, setShowGallery] = useState(false);
  
  // Get the most recent image
  const latestImage = satelliteState.images[0];
  
  const handleCaptureImage = async () => {
    setIsCapturing(true);
    try {
      await captureImage();
    } finally {
      setIsCapturing(false);
    }
  };
  
  return (
    <div className="bg-slate-800 rounded-lg shadow-lg p-4 text-white">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold">Camera Feed</h2>
        <div className="flex space-x-2">
          <button 
            className="p-2 bg-blue-600 rounded hover:bg-blue-700 transition"
            onClick={() => setShowGallery(!showGallery)}
          >
            {showGallery ? 'Show Live' : 'Show Gallery'}
          </button>
          <button 
            className={`p-2 bg-green-600 rounded hover:bg-green-700 transition ${isCapturing ? 'opacity-50 cursor-not-allowed' : ''}`}
            onClick={handleCaptureImage}
            disabled={isCapturing}
          >
            {isCapturing ? <RefreshCw className="animate-spin" /> : <Camera />}
          </button>
        </div>
      </div>
      
      {showGallery ? (
        <div className="mt-2">
          <h3 className="text-lg font-medium mb-2">Image Gallery</h3>
          <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
            {satelliteState.images.slice(0, 6).map((image) => (
              <div key={image.id} className="relative group">
                <img 
                  src={image.url} 
                  alt={`Satellite image ${image.id}`} 
                  className="rounded h-32 w-full object-cover"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <button className="p-1 bg-blue-600 rounded">
                    <Download size={16} />
                  </button>
                </div>
                <div className="text-xs text-gray-400 mt-1">
                  {new Date(image.timestamp).toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="relative flex flex-col items-center">
          {latestImage ? (
            <>
              <img 
                src={latestImage.url}
                alt="Live satellite feed" 
                className="rounded-md max-h-64 object-cover w-full"
              />
              <div className="absolute top-2 right-2 bg-black bg-opacity-60 px-2 py-1 rounded text-xs flex items-center">
                <div className="w-2 h-2 rounded-full bg-red-500 mr-1"></div>
                LIVE
              </div>
            </>
          ) : (
            <div className="bg-slate-900 rounded-md h-64 w-full flex items-center justify-center">
              <div className="text-center text-gray-500">
                <Camera size={48} className="mx-auto mb-2" />
                <p>No images captured yet</p>
                <button 
                  className="mt-4 px-4 py-2 bg-blue-600 rounded hover:bg-blue-700 transition"
                  onClick={handleCaptureImage}
                  disabled={isCapturing}
                >
                  {isCapturing ? 'Capturing...' : 'Capture Image'}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CameraFeed;