import React from 'react';
import { useSatellite } from '../../context/SatelliteContext';
import { Battery, Signal, Clock, Activity } from 'lucide-react';
import { formatDateTime } from '../../utils/mockData';

const StatusPanel: React.FC = () => {
  const { satelliteState } = useSatellite();
  const { status } = satelliteState;

  const getBatteryColor = (level: number) => {
    if (level > 70) return 'text-green-500';
    if (level > 30) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getSignalColor = (strength: number) => {
    if (strength > 70) return 'text-green-500';
    if (strength > 40) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <div className="bg-slate-800 rounded-lg shadow-lg p-4 text-white">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold">Satellite Status</h2>
        <div className={`px-3 py-1 rounded-full text-sm font-medium ${status.online ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
          {status.online ? 'Online' : 'Offline'}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="flex items-center space-x-2">
          <Battery className={`${getBatteryColor(status.batteryLevel)}`} />
          <div>
            <div className="text-sm text-gray-400">Battery</div>
            <div className="font-medium">{status.batteryLevel.toFixed(1)}%</div>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Signal className={`${getSignalColor(status.signalStrength)}`} />
          <div>
            <div className="text-sm text-gray-400">Signal</div>
            <div className="font-medium">{status.signalStrength.toFixed(1)}%</div>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Activity className="text-blue-500" />
          <div>
            <div className="text-sm text-gray-400">Orbit Status</div>
            <div className="font-medium">{status.orbitStatus}</div>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Clock className="text-blue-500" />
          <div>
            <div className="text-sm text-gray-400">Last Contact</div>
            <div className="font-medium text-xs">{formatDateTime(status.lastContact)}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatusPanel;