import React, { useState } from 'react';
import { useSatellite } from '../../context/SatelliteContext';
import { Terminal, Send, Check, X, RotateCw } from 'lucide-react';
import { Command } from '../../types/satellite';
import { formatDateTime } from '../../utils/mockData';

const CommandConsole: React.FC = () => {
  const { sendCommand, satelliteState } = useSatellite();
  const [commandType, setCommandType] = useState<Command['type']>('ATTITUDE_ADJUST');
  const [parameters, setParameters] = useState('');
  const [isSending, setIsSending] = useState(false);
  
  const handleSendCommand = async () => {
    setIsSending(true);
    try {
      let parsedParams = {};
      if (parameters) {
        try {
          parsedParams = JSON.parse(parameters);
        } catch (error) {
          console.error('Invalid JSON parameters:', error);
        }
      }
      
      await sendCommand({
        type: commandType,
        parameters: parsedParams
      });
    } finally {
      setIsSending(false);
    }
  };
  
  return (
    <div className="bg-slate-800 rounded-lg shadow-lg p-4 text-white">
      <div className="flex items-center mb-4">
        <Terminal className="mr-2 text-blue-500" />
        <h2 className="text-xl font-bold">Command Console</h2>
      </div>
      
      <div className="space-y-3 mb-4">
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">
            Command Type
          </label>
          <select
            value={commandType}
            onChange={(e) => setCommandType(e.target.value as Command['type'])}
            className="w-full bg-slate-700 rounded px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="ATTITUDE_ADJUST">Attitude Adjustment</option>
            <option value="POWER_CYCLE">Power Cycle</option>
            <option value="CAMERA_CAPTURE">Camera Capture</option>
            <option value="DATA_DOWNLINK">Data Downlink</option>
            <option value="SYSTEM_REBOOT">System Reboot</option>
            <option value="CUSTOM">Custom Command</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-1">
            Parameters (JSON)
          </label>
          <textarea
            value={parameters}
            onChange={(e) => setParameters(e.target.value)}
            placeholder='{"key": "value"}'
            className="w-full bg-slate-700 rounded px-3 py-2 text-white h-24 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        
        <button
          onClick={handleSendCommand}
          disabled={isSending}
          className={`w-full flex items-center justify-center py-2 rounded font-medium ${
            isSending 
              ? 'bg-gray-600 cursor-not-allowed' 
              : 'bg-blue-600 hover:bg-blue-700'
          } transition-colors`}
        >
          {isSending ? (
            <>
              <RotateCw className="mr-2 animate-spin" size={16} />
              Sending...
            </>
          ) : (
            <>
              <Send className="mr-2" size={16} />
              Send Command
            </>
          )}
        </button>
      </div>
      
      <div>
        <h3 className="text-sm font-medium text-gray-400 mb-2">Command History</h3>
        <div className="bg-slate-900 rounded p-2 h-48 overflow-y-auto font-mono text-xs">
          {satelliteState.commandHistory.length === 0 ? (
            <div className="text-gray-500 text-center mt-10">
              No commands have been sent yet
            </div>
          ) : (
            <div className="space-y-2">
              {[...satelliteState.commandHistory].reverse().map((cmd) => (
                <div key={cmd.id} className="border-l-2 pl-2 py-1 border-blue-500">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-blue-400">{cmd.type}</span>
                    <span className="text-gray-500">{formatDateTime(cmd.timestamp)}</span>
                  </div>
                  <div className="flex items-center mt-1 justify-between">
                    <div>
                      {cmd.status === 'COMPLETED' && cmd.response ? (
                        <span className={`inline-flex items-center ${
                          cmd.response.success ? 'text-green-500' : 'text-red-500'
                        }`}>
                          {cmd.response.success ? (
                            <Check size={14} className="mr-1" />
                          ) : (
                            <X size={14} className="mr-1" />
                          )}
                          {cmd.response.message}
                        </span>
                      ) : (
                        <span className="text-yellow-500 inline-flex items-center">
                          <RotateCw size={14} className="mr-1 animate-spin" />
                          {cmd.status}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CommandConsole;