import React from 'react';
import { useSatellite } from '../../context/SatelliteContext';
import { Battery, Zap, Sun } from 'lucide-react';
import { getStatusColor } from '../../utils/mockData';

const PowerPanel: React.FC = () => {
  const { satelliteState } = useSatellite();
  const { power } = satelliteState.currentSensorData;

  const powerItems = [
    { 
      label: 'Voltage', 
      value: `${power.voltage.toFixed(2)}V`,
      icon: <Zap size={18} />,
      colorClass: getStatusColor(power.voltage, { warning: 4.8, critical: 4.5 }, false) 
    },
    { 
      label: 'Current', 
      value: `${power.current.toFixed(2)}A`,
      icon: <Zap size={18} />,
      colorClass: getStatusColor(power.current, { warning: 1.2, critical: 1.5 }, true)
    },
    { 
      label: 'Solar Panel', 
      value: `${power.solarPanelOutput.toFixed(2)}W`,
      icon: <Sun size={18} />,
      colorClass: getStatusColor(power.solarPanelOutput, { warning: 3.0, critical: 2.0 }, false)
    }
  ];

  return (
    <div className="bg-slate-800 rounded-lg shadow-lg p-4 text-white">
      <h2 className="text-xl font-bold mb-4">Power Systems</h2>
      
      <div className="space-y-3">
        {powerItems.map((item, index) => (
          <div key={index} className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className={item.colorClass}>{item.icon}</span>
              <span className="text-gray-300">{item.label}</span>
            </div>
            <div className={`font-medium ${item.colorClass}`}>
              {item.value}
            </div>
          </div>
        ))}
      </div>
      
      {/* Battery level visualization */}
      <div className="mt-6">
        <div className="flex items-center justify-between text-sm mb-1">
          <div className="flex items-center">
            <Battery className="mr-1 text-blue-500" size={14} />
            <span>Battery Level</span>
          </div>
          <span>{satelliteState.status.batteryLevel.toFixed(1)}%</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-2.5">
          <div 
            className={`h-2.5 rounded-full ${
              satelliteState.status.batteryLevel > 70 
                ? 'bg-green-500' 
                : satelliteState.status.batteryLevel > 30 
                  ? 'bg-yellow-500' 
                  : 'bg-red-500'
            }`}
            style={{ width: `${satelliteState.status.batteryLevel}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default PowerPanel;