import React from 'react';
import { useSatellite } from '../../context/SatelliteContext';
import { Compass } from 'lucide-react';

const OrientationPanel: React.FC = () => {
  const { satelliteState } = useSatellite();
  const { orientation } = satelliteState.currentSensorData;
  
  const gaugeSize = 100;
  const strokeWidth = 8;
  const radius = (gaugeSize - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  
  // Normalize values to -180 to 180 range
  const normalizeValue = (value: number) => {
    // Convert to range [0, 1] where 0.5 is the center
    return (value + 180) / 360;
  };
  
  const getGaugeOffset = (value: number) => {
    // Get how much of the circle should be "empty"
    const normalizedValue = normalizeValue(value);
    return circumference - normalizedValue * circumference;
  };
  
  const getValueColor = (value: number) => {
    const absValue = Math.abs(value);
    if (absValue < 2) return 'text-green-500';
    if (absValue < 5) return 'text-yellow-500';
    return 'text-red-500';
  };
  
  return (
    <div className="bg-slate-800 rounded-lg shadow-lg p-4 text-white">
      <h2 className="text-xl font-bold mb-4">Orientation</h2>
      
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: 'Roll', value: orientation.roll },
          { label: 'Pitch', value: orientation.pitch },
          { label: 'Yaw', value: orientation.yaw }
        ].map((item) => (
          <div key={item.label} className="flex flex-col items-center">
            <svg width={gaugeSize} height={gaugeSize / 2 + 10} className="transform -rotate-90">
              <circle
                cx={gaugeSize / 2}
                cy={gaugeSize / 2}
                r={radius}
                fill="transparent"
                stroke="#374151"
                strokeWidth={strokeWidth}
                strokeDasharray={circumference}
                strokeDashoffset={circumference / 2}
                className="transition-all duration-300 ease-in-out"
              />
              <circle
                cx={gaugeSize / 2}
                cy={gaugeSize / 2}
                r={radius}
                fill="transparent"
                stroke="currentColor"
                strokeWidth={strokeWidth}
                strokeDasharray={circumference}
                strokeDashoffset={getGaugeOffset(item.value)}
                className={`transition-all duration-300 ease-in-out ${
                  Math.abs(item.value) < 2 
                    ? 'stroke-green-500' 
                    : Math.abs(item.value) < 5 
                      ? 'stroke-yellow-500' 
                      : 'stroke-red-500'
                }`}
              />
              <text 
                x={gaugeSize / 2} 
                y={gaugeSize / 2 + 5} 
                textAnchor="middle" 
                className={`text-sm font-bold fill-current ${getValueColor(item.value)}`}
                transform={`rotate(90 ${gaugeSize / 2} ${gaugeSize / 2})`}
              >
                {item.value.toFixed(1)}°
              </text>
            </svg>
            <div className="text-center mt-1">
              <div className="font-medium">{item.label}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OrientationPanel;