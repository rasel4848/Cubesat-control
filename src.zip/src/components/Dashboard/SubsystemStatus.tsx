import React from 'react';
import { useSatellite } from '../../context/SatelliteContext';
import { getSubsystemStatusColor } from '../../utils/mockData';
import { AlertCircle, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

const SubsystemStatus: React.FC = () => {
  const { satelliteState } = useSatellite();
  
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'NOMINAL':
        return <CheckCircle size={18} />;
      case 'WARNING':
        return <AlertTriangle size={18} />;
      case 'CRITICAL':
        return <AlertCircle size={18} />;
      case 'OFFLINE':
        return <XCircle size={18} />;
      default:
        return <CheckCircle size={18} />;
    }
  };
  
  return (
    <div className="bg-slate-800 rounded-lg shadow-lg p-4 text-white">
      <h2 className="text-xl font-bold mb-4">Subsystem Status</h2>
      
      <div className="grid grid-cols-2 gap-4">
        {satelliteState.subsystems.map((subsystem) => (
          <div 
            key={subsystem.name}
            className="flex items-center space-x-2 p-2 rounded bg-slate-700"
          >
            <span className={getSubsystemStatusColor(subsystem.status)}>
              {getStatusIcon(subsystem.status)}
            </span>
            <div>
              <div className="font-medium">{subsystem.name}</div>
              <div className="text-xs text-gray-400">
                {subsystem.message || subsystem.status.toLowerCase()}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SubsystemStatus;