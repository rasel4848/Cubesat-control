import React, { useState, useEffect } from 'react';
import { useSatellite } from '../../context/SatelliteContext';
import { HistoricalDataPoint } from '../../types/satellite';
import { LineChart, TrendingUp, Thermometer, Battery, Sun } from 'lucide-react';
import { formatTime } from '../../utils/mockData';

const DataVisualizer: React.FC = () => {
  const { satelliteState } = useSatellite();
  const [dataType, setDataType] = useState<'temperature' | 'power' | 'orientation'>('temperature');
  const [specificData, setSpecificData] = useState<string>('external');
  
  const [points, setPoints] = useState<Array<{ x: number; y: number; time: Date }>>([]);
  
  useEffect(() => {
    // Process data based on selected type and specific data point
    const processedPoints = satelliteState.dataHistory.map((point, index) => {
      let value = 0;
      
      if (dataType === 'temperature') {
        if (specificData === 'external') value = point.sensorData.temperature.external;
        else if (specificData === 'internal') value = point.sensorData.temperature.internal;
        else if (specificData === 'cpu') value = point.sensorData.temperature.components.cpu;
        else if (specificData === 'battery') value = point.sensorData.temperature.components.battery;
      } else if (dataType === 'power') {
        if (specificData === 'voltage') value = point.sensorData.power.voltage;
        else if (specificData === 'current') value = point.sensorData.power.current;
        else if (specificData === 'solar') value = point.sensorData.power.solarPanelOutput;
      } else if (dataType === 'orientation') {
        if (specificData === 'roll') value = point.sensorData.orientation.roll;
        else if (specificData === 'pitch') value = point.sensorData.orientation.pitch;
        else if (specificData === 'yaw') value = point.sensorData.orientation.yaw;
      }
      
      return {
        x: index,
        y: value,
        time: point.timestamp
      };
    });
    
    setPoints(processedPoints);
  }, [satelliteState.dataHistory, dataType, specificData]);
  
  // Determine min and max values for the chart
  const minValue = Math.min(...points.map(p => p.y));
  const maxValue = Math.max(...points.map(p => p.y));
  const range = maxValue - minValue;
  const paddedMin = minValue - range * 0.1;
  const paddedMax = maxValue + range * 0.1;
  
  // Calculate scale to fit in available height
  const chartHeight = 200;
  const scaleY = (value: number) => {
    return chartHeight - ((value - paddedMin) / (paddedMax - paddedMin) * chartHeight);
  };
  
  // Create path for the line
  const createLinePath = () => {
    if (points.length === 0) return '';
    
    return points.map((point, i) => {
      const x = (i / (points.length - 1)) * 100 + '%';
      const y = scaleY(point.y);
      return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
    }).join(' ');
  };
  
  const getDataTypeOptions = () => {
    if (dataType === 'temperature') {
      return [
        { value: 'external', label: 'External Temp' },
        { value: 'internal', label: 'Internal Temp' },
        { value: 'cpu', label: 'CPU Temp' },
        { value: 'battery', label: 'Battery Temp' }
      ];
    } else if (dataType === 'power') {
      return [
        { value: 'voltage', label: 'Voltage' },
        { value: 'current', label: 'Current' },
        { value: 'solar', label: 'Solar Output' }
      ];
    } else if (dataType === 'orientation') {
      return [
        { value: 'roll', label: 'Roll' },
        { value: 'pitch', label: 'Pitch' },
        { value: 'yaw', label: 'Yaw' }
      ];
    }
    return [];
  };
  
  const getDataIcon = () => {
    if (dataType === 'temperature') return <Thermometer className="text-red-500" size={18} />;
    if (dataType === 'power') {
      if (specificData === 'solar') return <Sun className="text-yellow-500" size={18} />;
      return <Battery className="text-green-500" size={18} />;
    }
    return <TrendingUp className="text-blue-500" size={18} />;
  };
  
  const getUnit = () => {
    if (dataType === 'temperature') return '°C';
    if (dataType === 'power') {
      if (specificData === 'voltage') return 'V';
      if (specificData === 'current') return 'A';
      if (specificData === 'solar') return 'W';
    }
    if (dataType === 'orientation') return '°';
    return '';
  };
  
  return (
    <div className="bg-slate-800 rounded-lg shadow-lg p-4 text-white">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <LineChart className="mr-2 text-blue-500" />
          <h2 className="text-xl font-bold">Data Visualization</h2>
        </div>
        
        <div className="flex space-x-2">
          <select
            value={dataType}
            onChange={(e) => {
              setDataType(e.target.value as any);
              // Reset specific data to first option
              if (e.target.value === 'temperature') setSpecificData('external');
              else if (e.target.value === 'power') setSpecificData('voltage');
              else if (e.target.value === 'orientation') setSpecificData('roll');
            }}
            className="bg-slate-700 rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
          >
            <option value="temperature">Temperature</option>
            <option value="power">Power</option>
            <option value="orientation">Orientation</option>
          </select>
          
          <select
            value={specificData}
            onChange={(e) => setSpecificData(e.target.value)}
            className="bg-slate-700 rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
          >
            {getDataTypeOptions().map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      <div className="relative">
        {/* Chart container */}
        <div className="h-64 relative">
          {/* Y-axis labels */}
          <div className="absolute left-0 top-0 bottom-0 w-12 flex flex-col justify-between text-xs text-gray-400">
            <div>{paddedMax.toFixed(1)}{getUnit()}</div>
            <div>{((paddedMax + paddedMin) / 2).toFixed(1)}{getUnit()}</div>
            <div>{paddedMin.toFixed(1)}{getUnit()}</div>
          </div>
          
          {/* Chart area */}
          <div className="absolute left-14 right-0 top-0 bottom-0">
            {/* Grid lines */}
            <div className="absolute inset-0 border-b border-l border-gray-700 grid grid-cols-6 grid-rows-4">
              {Array.from({ length: 24 }).map((_, i) => (
                <div key={i} className="border-t border-r border-gray-700" />
              ))}
            </div>
            
            {/* Data line */}
            <svg
              className="absolute inset-0 w-full h-full overflow-visible"
              preserveAspectRatio="none"
            >
              <path
                d={createLinePath()}
                fill="none"
                stroke={
                  dataType === 'temperature' ? '#ef4444' :
                  dataType === 'power' ? '#22c55e' : '#3b82f6'
                }
                strokeWidth="2"
                className="transition-all duration-300 ease-in-out"
              />
              
              {/* Data points */}
              {points.map((point, i) => (
                <circle
                  key={i}
                  cx={`${(i / (points.length - 1)) * 100}%`}
                  cy={scaleY(point.y)}
                  r="2"
                  fill={
                    dataType === 'temperature' ? '#ef4444' :
                    dataType === 'power' ? '#22c55e' : '#3b82f6'
                  }
                  className="transition-all duration-300 ease-in-out"
                />
              ))}
            </svg>
          </div>
        </div>
        
        {/* X-axis labels */}
        <div className="flex justify-between text-xs text-gray-400 pl-14 mt-1">
          {[0, 1, 2, 3, 4, 5].map(i => {
            const index = Math.floor(points.length / 6 * i);
            const point = points[index];
            return (
              <div key={i}>
                {point ? formatTime(point.time) : ''}
              </div>
            );
          })}
        </div>
        
        {/* Current value */}
        <div className="flex items-center mt-2 pl-14">
          {getDataIcon()}
          <span className="ml-1 font-medium">
            Current: {points.length ? points[points.length - 1].y.toFixed(2) : '0'}{getUnit()}
          </span>
        </div>
      </div>
    </div>
  );
};

export default DataVisualizer;