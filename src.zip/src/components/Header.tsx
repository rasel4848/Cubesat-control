import React from 'react';
import { Satellite, Menu, Bell } from 'lucide-react';
import { useSatellite } from '../context/SatelliteContext';

const Header: React.FC = () => {
  const { satelliteState } = useSatellite();
  
  return (
    <header className="bg-slate-900 text-white py-3 px-4 shadow-lg sticky top-0 z-10">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center">
          <Satellite className="text-blue-500 mr-2" size={28} />
          <div>
            <h1 className="text-xl font-bold">CubeSat Control</h1>
            <p className="text-xs text-gray-400">Ground Station Interface</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className={`px-2 py-1 rounded-full text-xs font-medium flex items-center 
            ${satelliteState.isLiveConnection ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}
          >
            <span className={`w-2 h-2 rounded-full mr-1 ${satelliteState.isLiveConnection ? 'bg-green-500' : 'bg-red-500'}`}></span>
            {satelliteState.isLiveConnection ? 'Connected' : 'Disconnected'}
          </div>
          
          <div className="p-2 relative group">
            <Bell size={20} className="text-gray-400 group-hover:text-white transition-colors" />
            <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 rounded-full text-[10px] flex items-center justify-center">
              3
            </span>
          </div>
          
          <button className="p-2 rounded hover:bg-slate-800 transition-colors">
            <Menu size={20} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;