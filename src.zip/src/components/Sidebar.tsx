import React from 'react';
import { 
  LayoutDashboard, 
  Camera, 
  LineChart, 
  Terminal, 
  Settings, 
  AlertCircle, 
  Users, 
  Satellite,
  HelpCircle
} from 'lucide-react';

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, active }) => {
  return (
    <div 
      className={`flex items-center space-x-3 px-4 py-3 rounded-md cursor-pointer
        transition-colors ${active 
          ? 'bg-blue-900/30 text-blue-400' 
          : 'text-gray-400 hover:bg-slate-800 hover:text-white'
        }`}
    >
      {icon}
      <span className="font-medium">{label}</span>
    </div>
  );
};

const Sidebar: React.FC = () => {
  return (
    <div className="w-64 bg-slate-900 text-white flex flex-col h-full">
      <div className="p-4">
        <div className="flex items-center space-x-2 mb-6">
          <Satellite className="text-blue-500" size={28} />
          <div className="font-bold text-xl">CubeSat Control</div>
        </div>
        
        <div className="space-y-1">
          <SidebarItem icon={<LayoutDashboard size={18} />} label="Dashboard" active />
          <SidebarItem icon={<Camera size={18} />} label="Camera" />
          <SidebarItem icon={<LineChart size={18} />} label="Telemetry" />
          <SidebarItem icon={<Terminal size={18} />} label="Command Center" />
          <SidebarItem icon={<AlertCircle size={18} />} label="Alerts" />
        </div>
        
        <div className="mt-8 mb-2 px-4 text-xs font-semibold text-gray-500 uppercase">
          System
        </div>
        
        <div className="space-y-1">
          <SidebarItem icon={<Settings size={18} />} label="Settings" />
          <SidebarItem icon={<Users size={18} />} label="Team Access" />
          <SidebarItem icon={<HelpCircle size={18} />} label="Support" />
        </div>
      </div>
      
      <div className="mt-auto p-4 border-t border-slate-800">
        <div className="bg-blue-900/20 rounded-md p-3 text-sm">
          <div className="font-semibold text-blue-400 mb-1">Mission: Explorer-1</div>
          <div className="text-gray-400 text-xs">
            <div>Orbit: LEO 400km</div>
            <div>Launch Date: Jan 15, 2025</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;