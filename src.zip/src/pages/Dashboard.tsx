import React from 'react';
import StatusPanel from '../components/Dashboard/StatusPanel';
import TemperaturePanel from '../components/Dashboard/TemperaturePanel';
import CameraFeed from '../components/Dashboard/CameraFeed';
import SubsystemStatus from '../components/Dashboard/SubsystemStatus';
import PowerPanel from '../components/Dashboard/PowerPanel';
import OrientationPanel from '../components/Dashboard/OrientationPanel';
import CommandConsole from '../components/Dashboard/CommandConsole';
import DataVisualizer from '../components/Dashboard/DataVisualizer';

const Dashboard: React.FC = () => {
  return (
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <StatusPanel />
      <TemperaturePanel />
      <PowerPanel />
      <div className="lg:col-span-2">
        <CameraFeed />
      </div>
      <OrientationPanel />
      <div className="lg:col-span-2">
        <DataVisualizer />
      </div>
      <SubsystemStatus />
      <div className="md:col-span-2 lg:col-span-2">
        <CommandConsole />
      </div>
    </div>
  );
};

export default Dashboard;