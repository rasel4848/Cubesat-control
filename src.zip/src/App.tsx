import React from 'react';
import { SatelliteProvider } from './context/SatelliteContext';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';

function App() {
  return (
    <SatelliteProvider>
      <div className="min-h-screen bg-slate-950 text-white flex flex-col">
        <Header />
        <div className="flex flex-1 overflow-hidden">
          <Sidebar />
          <main className="flex-1 overflow-y-auto bg-slate-900">
            <Dashboard />
          </main>
        </div>
      </div>
    </SatelliteProvider>
  );
}

export default App;