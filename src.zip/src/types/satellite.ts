export interface SatelliteStatus {
  online: boolean;
  batteryLevel: number;
  signalStrength: number;
  orbitStatus: string;
  lastContact: Date;
}

export interface SensorData {
  temperature: {
    external: number;
    internal: number;
    components: {
      cpu: number;
      battery: number;
      camera: number;
    };
  };
  power: {
    voltage: number;
    current: number;
    solarPanelOutput: number;
  };
  orientation: {
    roll: number;
    pitch: number;
    yaw: number;
  };
  radiation: number;
}

export interface Command {
  id: string;
  type: 'ATTITUDE_ADJUST' | 'POWER_CYCLE' | 'CAMERA_CAPTURE' | 'DATA_DOWNLINK' | 'SYSTEM_REBOOT' | 'CUSTOM';
  parameters?: Record<string, any>;
  status: 'QUEUED' | 'SENT' | 'RECEIVED' | 'EXECUTING' | 'COMPLETED' | 'FAILED';
  timestamp: Date;
  response?: {
    success: boolean;
    message: string;
    data?: any;
  };
}

export interface HistoricalDataPoint {
  timestamp: Date;
  sensorData: SensorData;
  status: SatelliteStatus;
}

export interface CameraImage {
  id: string;
  url: string;
  timestamp: Date;
  caption?: string;
}

export interface SubsystemStatus {
  name: string;
  status: 'NOMINAL' | 'WARNING' | 'CRITICAL' | 'OFFLINE';
  message?: string;
}

export interface SatelliteState {
  status: SatelliteStatus;
  currentSensorData: SensorData;
  subsystems: SubsystemStatus[];
  commandHistory: Command[];
  dataHistory: HistoricalDataPoint[];
  images: CameraImage[];
  isLiveConnection: boolean;
}