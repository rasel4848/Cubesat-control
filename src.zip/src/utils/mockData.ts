import { SensorData } from '../types/satellite';

// Generate mock sensor data with some variance
export const generateMockData = (seed: number): SensorData => {
  const random = (min: number, max: number) => {
    // Use seed to create deterministic but varying random values
    const seedRandom = Math.sin(seed % 10000) * 10000;
    const r = Math.abs(seedRandom) % 1;
    return min + r * (max - min);
  };

  const baseTemp = -20 + (Math.sin(seed / 5000) * 10);
  
  return {
    temperature: {
      external: baseTemp + random(-2, 2),
      internal: 22 + random(-1, 1),
      components: {
        cpu: 45 + random(-5, 8),
        battery: 33 + random(-3, 5),
        camera: 28 + random(-2, 4)
      }
    },
    power: {
      voltage: 5.0 + random(-0.2, 0.3),
      current: 0.8 + random(-0.1, 0.2),
      solarPanelOutput: 4.0 + random(-0.5, 0.8) + Math.sin(seed / 10000) * 2
    },
    orientation: {
      roll: random(-1, 1),
      pitch: random(-2, 2),
      yaw: random(-1, 1)
    },
    radiation: 0.04 + random(-0.01, 0.02)
  };
};

// Get status color based on value and thresholds
export const getStatusColor = (
  value: number, 
  thresholds: { warning: number; critical: number; },
  isHighBad = true
): string => {
  if (isHighBad) {
    if (value >= thresholds.critical) return 'text-red-500';
    if (value >= thresholds.warning) return 'text-yellow-500';
    return 'text-green-500';
  } else {
    if (value <= thresholds.critical) return 'text-red-500';
    if (value <= thresholds.warning) return 'text-yellow-500';
    return 'text-green-500';
  }
};

// Get a color for subsystem status
export const getSubsystemStatusColor = (status: string): string => {
  switch (status) {
    case 'NOMINAL': return 'text-green-500';
    case 'WARNING': return 'text-yellow-500';
    case 'CRITICAL': return 'text-red-500';
    case 'OFFLINE': return 'text-gray-500';
    default: return 'text-blue-500';
  }
};

// Format temperature with proper unit
export const formatTemperature = (temp: number): string => {
  return `${temp.toFixed(1)}°C`;
};

// Format date/time
export const formatDateTime = (date: Date): string => {
  return date.toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
};

// Format time only
export const formatTime = (date: Date): string => {
  return date.toLocaleString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
};