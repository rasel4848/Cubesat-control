import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { SatelliteState, Command, CameraImage, SubsystemStatus } from '../types/satellite';
import { generateMockData } from '../utils/mockData';

// Create the context with a default undefined value
const SatelliteContext = createContext<{
  satelliteState: SatelliteState;
  sendCommand: (command: Omit<Command, 'id' | 'timestamp' | 'status'>) => Promise<Command>;
  captureImage: () => Promise<CameraImage>;
  updateSubsystemStatus: (name: string, status: SubsystemStatus['status'], message?: string) => void;
} | undefined>(undefined);

// Initial state
const initialState: SatelliteState = {
  status: {
    online: true,
    batteryLevel: 87,
    signalStrength: 76,
    orbitStatus: 'Nominal',
    lastContact: new Date()
  },
  currentSensorData: {
    temperature: {
      external: -15.7,
      internal: 22.3,
      components: {
        cpu: 45.2,
        battery: 32.8,
        camera: 28.5
      }
    },
    power: {
      voltage: 5.2,
      current: 0.8,
      solarPanelOutput: 4.3
    },
    orientation: {
      roll: 0.2,
      pitch: 1.5,
      yaw: -0.3
    },
    radiation: 0.042
  },
  subsystems: [
    { name: 'Power', status: 'NOMINAL' },
    { name: 'Thermal', status: 'NOMINAL' },
    { name: 'Communication', status: 'NOMINAL' },
    { name: 'Attitude Control', status: 'NOMINAL' },
    { name: 'Camera', status: 'NOMINAL' },
    { name: 'Payload', status: 'NOMINAL' }
  ],
  commandHistory: [],
  dataHistory: [],
  images: [],
  isLiveConnection: true
};

export const SatelliteProvider = ({ children }: { children: ReactNode }) => {
  const [satelliteState, setSatelliteState] = useState<SatelliteState>(initialState);

  useEffect(() => {
    // On mount, populate with initial historical data
    const initialHistory = Array.from({ length: 100 }, (_, i) => ({
      timestamp: new Date(Date.now() - (99 - i) * 60000),
      sensorData: generateMockData(i),
      status: {...initialState.status, lastContact: new Date(Date.now() - (99 - i) * 60000)}
    }));

    setSatelliteState(prev => ({
      ...prev,
      dataHistory: initialHistory
    }));

    // Simulate real-time data updates
    const intervalId = setInterval(() => {
      setSatelliteState(prev => {
        const newData = generateMockData(Date.now());
        const newHistory = [...prev.dataHistory, {
          timestamp: new Date(),
          sensorData: newData,
          status: {...prev.status, lastContact: new Date()}
        }];

        // Keep only the last 100 data points
        if (newHistory.length > 100) {
          newHistory.shift();
        }

        return {
          ...prev,
          currentSensorData: newData,
          dataHistory: newHistory,
          status: {
            ...prev.status,
            batteryLevel: 75 + Math.random() * 20,
            signalStrength: 70 + Math.random() * 25,
            lastContact: new Date()
          }
        };
      });
    }, 5000);

    return () => clearInterval(intervalId);
  }, []);

  const sendCommand = async (
    commandData: Omit<Command, 'id' | 'timestamp' | 'status'>
  ): Promise<Command> => {
    // Create a new command with generated ID
    const newCommand: Command = {
      id: Math.random().toString(36).substr(2, 9),
      ...commandData,
      timestamp: new Date(),
      status: 'QUEUED'
    };

    // Add to command history
    setSatelliteState(prev => ({
      ...prev,
      commandHistory: [...prev.commandHistory, newCommand]
    }));

    // Simulate command processing
    return new Promise((resolve) => {
      setTimeout(() => {
        const updatedCommand = {
          ...newCommand,
          status: 'COMPLETED',
          response: {
            success: Math.random() > 0.1, // 90% success rate
            message: Math.random() > 0.1 ? 'Command executed successfully' : 'Command execution failed',
          }
        };

        setSatelliteState(prev => ({
          ...prev,
          commandHistory: prev.commandHistory.map(cmd => 
            cmd.id === newCommand.id ? updatedCommand : cmd
          )
        }));

        resolve(updatedCommand);
      }, 2000);
    });
  };

  const captureImage = async (): Promise<CameraImage> => {
    // Simulate capturing an image
    return new Promise((resolve) => {
      setTimeout(() => {
        const newImage: CameraImage = {
          id: Math.random().toString(36).substr(2, 9),
          url: `https://images.pexels.com/photos/355935/pexels-photo-355935.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2`,
          timestamp: new Date()
        };

        setSatelliteState(prev => ({
          ...prev,
          images: [newImage, ...prev.images].slice(0, 50) // Keep only the latest 50 images
        }));

        resolve(newImage);
      }, 3000);
    });
  };

  const updateSubsystemStatus = (
    name: string,
    status: SubsystemStatus['status'],
    message?: string
  ) => {
    setSatelliteState(prev => ({
      ...prev,
      subsystems: prev.subsystems.map(subsystem => 
        subsystem.name === name ? { ...subsystem, status, message } : subsystem
      )
    }));
  };

  const value = {
    satelliteState,
    sendCommand,
    captureImage,
    updateSubsystemStatus
  };

  return (
    <SatelliteContext.Provider value={value}>
      {children}
    </SatelliteContext.Provider>
  );
};

export const useSatellite = () => {
  const context = useContext(SatelliteContext);
  if (context === undefined) {
    throw new Error('useSatellite must be used within a SatelliteProvider');
  }
  return context;
};